//
//  ViewController.swift
//  Dogs
//
//  Created by  on 12/08/2021
//

import UIKit

class ViewController: UIViewController {

    
    var animal1 : Animal = Animal()
    var animal2 : Animal = Animal()

    
    
    var bullDog = Animal(breed: "Bull Dog", description: " A breed muscular,hefty with a wrinkled face ", image: UIImage(named: "BullDog")!)
    

    var goldenRetiever = Animal(breed: "Golden Retrevier", description: "A breed that is loving and friendly", image: UIImage(named: "golden")!)
    // Configure the cell...
    
    var persian = Animal(breed: "Persian ", description: "known as Longhair also", image: UIImage(named: "persian")!)
    
    var maineCoon = Animal(breed: "Maine Coon", description: "One of the oldest breed in North America", image: UIImage(named: "maineCoon")!)
    
    
    
    

    @IBOutlet weak var dogDetails: UIImageView!

    @IBOutlet weak var catDetails: UIImageView!
    
    
  
    

    
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dogDetails.image  = UIImage (named: "dogTypes")
        catDetails.image = UIImage(named: "catTypes")
        
        
      
        
        
        
    }
        
        
        

        
    @IBAction func dogButton(_ sender: Any) {
        
        animal1 = bullDog
        animal2 = goldenRetiever
        self.performSegue(withIdentifier: "firstSegue", sender: nil)
        
    }
    
    @IBAction func catButton(_ sender: Any) {
        
        animal1 = persian
        animal2 = maineCoon
        self.performSegue(withIdentifier: "firstSegue", sender: nil)
        
    

}

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var vc = segue.destination as! DetailVCTableViewController
        vc.selectedDog = [self.animal1, self.animal2]
        
    }


}
