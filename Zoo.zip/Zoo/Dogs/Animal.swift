//
//  Animal.swift
//  Animal
//
//  Created by  on 12/08/21.
//

import Foundation

import UIKit



class Animal {
    
    var breed : String
    var description : String
    var image : UIImage
    
    init () {
        self.image = UIImage()
        self.breed = ""
        self.description = ""
    }
    
    init(breed : String, description : String, image : UIImage){
        self.breed = breed
        self.description = description
        self.image = image
    }
}
